<script>
export default {
  data() {
    return {
      query: null,
      receptk: null,
    };
  },
  methods: {
      async fetchFood() {
      try {
        const response = await fetch(`https://api.spoonacular.com/recipes/complexSearch?apiKey=7d141d481c3a4501b2fcc6f3331753b7&query=${this.query}&addRecipeInformation=true`);
        const data = await response.json();
        this.receptk = data.results;
        console.log(this.receptk)
      } catch (error) {
        console.error('Hiba történt az adatok lekérésekor:', error);
      }
    },
  },
  mounted() {
    this.fetchFood();
  },
};
</script>

<template>
<h1>Receptkereső</h1>
<div class="search">

<input type="text" id="query" class="query" v-model="query" placeholder="Keressen valamire">
<button @click="fetchFood" class="btn">Keresés</button>
</div>
<div class="container">
  <div v-for="recept in receptk" class="card">
  <p :key="recept">{{ recept.title }}</p>
  <img :key="recept" :src="recept.image" :alt="recept.title" class="fodim">
  <p v-html="recept.summary"></p>
  </div>
</div>
</template>
<style>
h1{
  display: flex;
  justify-content: center;
  margin-bottom: 20px;
}
.search{
  display: flex;
  justify-content: center;
  margin-bottom: 20px;
}
.query{
  width: 200px;
  height: 20px;
  margin-right: 10px;
}
.btn{
  width: 100px;
  height: 20px;
}
.container {
  display: flex;
  flex-wrap: wrap;
  gap: 16px;
  justify-content: center;
}
.card {
  margin: 20px;
  padding: 20px;
  border: 1px solid #ccc;
  border-radius: 5px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  text-align: center;
  background-color: #f9f9f9;
  color: #333;
  font-family: Arial, sans-serif;
  font-size: 16px;
  line-height: 1.5;

}

.card:hover {
  background-color: #e9e9e9;
}
.fodim {
  max-width: 100%;
  height: auto;
  padding: 20px;
  border: 1px solid #ccc;
  border-radius: 5px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  text-align: center;
  background-color: #f9f9f9;
  color: #333;
  font-family: Arial, sans-serif;
  font-size: 16px;
  line-height: 1.5;
}
</style>